import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpService {             //ng g s emp --skip-tests
  public isUserLogged: boolean;

  constructor(public httpClient: HttpClient) {    //dependency injection for HttpClient
    this.isUserLogged = false;
  }
  
  public setUserLoggedIn(): void {
    this.isUserLogged = true;
  }
  public getUserLoggedIn(): any {
    return this.isUserLogged;
  }

  public getAllCountries(): any {
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
  }
  
  //Logout
  public setUserLoggedOut(): void {
    this.isUserLogged = false;
  }

  getAllEmployees(): any {
    return this.httpClient.get('showAllEmployee');
  }

  getEmpById(employeeId: any): any {
    return this.httpClient.get('getEmpById/' + employeeId);
  }

  register(employee: any): any {
    return this.httpClient.post('registerEmp', employee);
  }

  deleteEmployee(employee: any): any {
    return this.httpClient.post('deleteEmp', employee);
  }

  updateEmployee(employee: any): any {
    return this.httpClient.post('updateEmp', employee);
  }

  getEmployee(loginId: any, password: any): any {
    return this.httpClient.get('getEmployee/' + loginId + '/' + password);
  }
}
