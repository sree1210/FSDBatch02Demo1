import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';

declare var jQuery: any;

@Component({
  selector: 'app-showemp',
  templateUrl: './showemp.component.html',
  styleUrls: ['./showemp.component.css']
})
export class ShowempComponent implements OnInit {
  
  editEmployee: any;
  employees: any;

  constructor(public service: EmpService) {     //Dependency Injection for EmpService    
  }  

  ngOnInit(): void {
    this.service.getAllEmployees().subscribe((data: any) => {console.log(data), this.employees = data;});
    this.editEmployee = {empId:'', empName:'', salary:'', gender:'', doj:'', mobile:'', country:'', loginId:'', password:''};
  }

  deleteEmp(employee: any) {
    console.log('Deleted Employee: ');
    console.log(employee);

    this.service.deleteEmployee(employee).subscribe((data: any) => {
      const i = this.employees.findIndex((record: any) => {return record.empId === employee.empId;})
      this.employees.splice(i, 1);
    });
  }

  showEditPopup(employee: any): void {
    this.editEmployee = employee;
    jQuery('#empModel').modal('show');
  }

  updateEmp(): void {
    console.log(this.editEmployee);
    this.service.updateEmployee(this.editEmployee).subscribe();
  }


  //Default Date Format : mm-dd-yy
   // this.employees = [
    //   {empId:1, empName:'Pasha',  salary:9999.99, gender:'M', doj:'02-19-82', loginId:'pasha123',  password:'password'},
    //   {empId:2, empName:'Harsha', salary:8888.88, gender:'M', doj:'02-19-83', loginId:'harsha123', password:'password'},
    //   {empId:3, empName:'Indira', salary:7777.77, gender:'F', doj:'02-19-84', loginId:'indira123', password:'password'},
    //   {empId:4, empName:'Venkat', salary:6666.66, gender:'M', doj:'02-19-85', loginId:'venkat123', password:'password'},
    //   {empId:5, empName:'Gopi',   salary:5555.55, gender:'M', doj:'02-19-86', loginId:'gopi123',   password:'password'},
    //   {empId:6, empName:'Rani',   salary:4444.44, gender:'f', doj:new Date(), loginId:'RANI123',   password:'PASSWORD'}
    // ];

}
