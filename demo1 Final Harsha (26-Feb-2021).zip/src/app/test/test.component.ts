import { Component, OnInit, SystemJsNgModuleLoader } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  age: number;
  name: String;
  salary: number;
  isMarried: boolean;
  address: any;
  hobbies: any;

  message: any;

  constructor() { 
    console.log('Hi! This is Constructor');

    this.message='';

    this.age=45;
    this.name='SACHIN';
    this.salary=9999.99;
    this.isMarried=true;
    this.address={doorNo:'10-20', street:'EAST', city:'MUMBAI'};
    this.hobbies=['PLAYING', 'SINGING', 'CHATTING', 'EATING'];
  }

  ngOnInit(): void {
    console.log('Hi! This is ngOnInit');
  }

  
  showMessage(): void {
    alert('showMessage() is Called...');
    console.log('Message : ' + this.message);
  }

}
