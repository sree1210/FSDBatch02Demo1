import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-empbyid',
  templateUrl: './empbyid.component.html',
  styleUrls: ['./empbyid.component.css']
})
export class EmpbyidComponent implements OnInit {

  public employeeId: number;
  employee: any;

  constructor(public service: EmpService) {   //dependency injection for EmpService 
    this.employeeId = 0;
  }

  ngOnInit(): void {
  }

  getEmpById(): void {
    this.service.getEmpById(this.employeeId).subscribe((data: any) => {console.log(data), this.employee = data;});
  }

}
