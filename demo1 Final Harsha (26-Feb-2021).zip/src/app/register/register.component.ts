import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  countriesList: any;

  constructor(public service: EmpService) {   //dependency injection for EmpService
  }

  ngOnInit(): void {
    this.service.getAllCountries().subscribe((data: any) => {console.log(data), this.countriesList=data;});
  }

  registeruser(regForm: any) {
    console.log("User Registration Details:");
    console.log(regForm); 

    this.service.register(regForm).subscribe((result: any) => console.log(result));
  }
}
