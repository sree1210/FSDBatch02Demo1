import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any;
  employee: any;
  constructor(public router: Router, public empService: EmpService) {        // Dependency Injection for Router & EmpService Class
    this.user = {loginId:'', password:''};
   }

  ngOnInit(): void {
  }
  loginSubmit(): void {
    console.log("User Data:");
    console.log(this.user.loginId);
    console.log(this.user.password);
  }

  async submitLoginForm(loginForm: any) {
    console.log("LoginForm Object Data : ");
    console.log(loginForm);

    if(loginForm.loginId === 'admin' && loginForm.password === 'admin') {     
      this.empService.setUserLoggedIn();    //made return value to true     
      this.router.navigate(['products']);
    } else {
      
      await this.empService.getEmployee(loginForm.loginId, loginForm.password).toPromise().then((data: any) => {console.log(data); this.employee = data;});

      if(this.employee) {
        alert("Login Success");
        this.empService.setUserLoggedIn();
        this.router.navigate(['products']);
      } else {
        alert("Login Failed!");
        this.router.navigate(['registration']);
      }
    }
  }

}
